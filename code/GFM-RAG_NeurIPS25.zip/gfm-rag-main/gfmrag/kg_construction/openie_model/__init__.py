from .base_model import BaseOPENIEModel
from .llm_openie_model import LLMOPENIEModel

__all__ = ["BaseOPENIEModel", "LLMOPENIEModel"]
