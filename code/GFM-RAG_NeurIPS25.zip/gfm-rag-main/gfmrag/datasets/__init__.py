from .kg_dataset import KGDataset
from .qa_dataset import QADataset

__all__ = ["KGDataset", "QADataset"]
