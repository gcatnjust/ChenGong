::: gfmrag.prompt_builder
