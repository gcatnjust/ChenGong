::: gfmrag.kg_construction.entity_linking_model
