::: gfmrag.models
    options:
        heading_level: 1


::: gfmrag.ultra.models.EntityNBFNet

::: gfmrag.ultra.models.QueryNBFNet
