
clear 
load 'training.mat'
M = aml_bi_level(X, y, 10, 1);