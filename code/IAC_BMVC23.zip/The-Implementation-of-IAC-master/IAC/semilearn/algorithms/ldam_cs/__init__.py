# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

from .ldam_cs import LDAM_cs