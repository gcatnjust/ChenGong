# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

from .cifarstl import get_cifarstl
from .pacs import get_pacs
from .digit_five import get_digit_five
