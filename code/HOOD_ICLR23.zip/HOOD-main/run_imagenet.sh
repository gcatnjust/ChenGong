python main.py --dataset imagenet --out $1 --arch resnet_imagenet --lambda_oem 0.1 --lambda_socr 0.5 \
--batch-size 64 --lr 0.03 --expand-labels --seed 0 --opt_level O2 --amp --mu 2 --epochs 100







