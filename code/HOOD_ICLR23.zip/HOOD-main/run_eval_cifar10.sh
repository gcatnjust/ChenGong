python main.py --dataset cifar10 --resume $1 --arch wideresnet --eval_only 1






