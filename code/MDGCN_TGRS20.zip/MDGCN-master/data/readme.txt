For each dataset, the normalized image data, the groud-truth map, and the segmented map are needed. Note that the segmented maps have already been provided, and the other two files can be downloaded online.


