from .KD import DistillKL
from .KD import HintLoss
