





python main.py --gpu '0, 1' --n-workers 2 --model fedhvae --dataset Questions --mode overlapping --frac 1.0 --n-rnds 100 --n-eps 1 --n-clients 50 --seed 42


python main.py --gpu '0, 1' --n-workers 2 --model fedhvae --dataset Questions --mode overlapping --frac 1.0 --n-rnds 100 --n-eps 1 --n-clients 50 --seed 42


python main.py --gpu '0, 1' --n-workers 2 --model fedhvae --dataset Questions --mode overlapping --frac 1.0 --n-rnds 100 --n-eps 1 --n-clients 30 --seed 42


python main.py --gpu '0, 1' --n-workers 2 --model fedhvae --dataset Questions --mode overlapping --frac 1.0 --n-rnds 100 --n-eps 1 --n-clients 30 --seed 42




python main.py --gpu '0, 1' --n-workers 2 --model fedhvae --dataset Questions --mode overlapping --frac 1.0 --n-rnds 100 --n-eps 1 --n-clients 10 --seed 42


python main.py --gpu '0, 1' --n-workers 2 --model fedhvae --dataset Questions --mode overlapping --frac 1.0 --n-rnds 100 --n-eps 1 --n-clients 10 --seed 42







