

python main.py --gpu '0, 1' --n-workers 2 --model fedhvae --dataset Minesweeper --mode disjoint --frac 1.0 --n-rnds 100 --n-eps 1 --n-clients 20 --seed 42

python main.py --gpu '0, 1' --n-workers 2 --model fedhvae --dataset Minesweeper --mode disjoint --frac 1.0 --n-rnds 100 --n-eps 1 --n-clients 20 --seed 42

python main.py --gpu '0, 1' --n-workers 2 --model fedhvae --dataset Minesweeper --mode disjoint --frac 1.0 --n-rnds 100 --n-eps 1 --n-clients 20 --seed 42
