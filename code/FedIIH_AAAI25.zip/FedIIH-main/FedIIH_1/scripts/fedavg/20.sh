CUDA_VISIBLE_DEVICES=0 python main.py --gpu 0 --n-workers 5 --model fedavg --dataset Cora --mode disjoint --frac 1.0 --n-rnds 100 --n-eps 1 --n-clients 20 --seed 42

CUDA_VISIBLE_DEVICES=0 python main.py --gpu 0 --n-workers 5 --model fedavg --dataset Cora --mode disjoint --frac 1.0 --n-rnds 100 --n-eps 1 --n-clients 20 --seed 42

CUDA_VISIBLE_DEVICES=0 python main.py --gpu 0 --n-workers 5 --model fedavg --dataset Cora --mode disjoint --frac 1.0 --n-rnds 100 --n-eps 1 --n-clients 20 --seed 42
