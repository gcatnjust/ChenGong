# FB15k-237
nohup python main.py --few 3 --dataset FB15k-237 --negative-sample 32 > FB15k-237-3.txt
# NELL-995
nohup python main.py --few 3 --dataset NELL-995 --negative-sample 64 > NELL-995-3.txt